from geospacelab.config._preferences import preferences
