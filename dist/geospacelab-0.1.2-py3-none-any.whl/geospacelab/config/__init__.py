import geospacelab.config._preferences as prf

preferences = prf.Preferences()
