# geospacelab
To collect, manage, visualize geospace data.

## Installation

### Pre-requirements
The package was tested in a conda evironment with python (version>3.6). Install the dependencies below before the installation. 

```sh
conda install h5py
conda install netcdf
conda install cartopy 
pip install scipy
pip install numpy
pip install matplotlib
pip install madrigalweb
```


